import {HomeComponent} from './home.component';
import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterOutlet } from '@angular/router';
import { By } from '@angular/platform-browser';

describe('HomeComponent' , ()=> {
   let component : HomeComponent;    
   beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[
        RouterTestingModule.withRoutes([]) 
      ],
      declarations: [
        HomeComponent
      ],
    }).compileComponents();
  }));

   it("should create Home component", () => {
    expect(component).toBeTruthy();
  });
   
   it("should have a router outlet" , ()=>{
    const fixture = TestBed.createComponent(HomeComponent);
    let de = fixture.debugElement.query(By.directive(RouterOutlet));
  //  expect(de).not.toBeNull();
   });

});