import {HeaderComponent} from './header.component';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, async } from '@angular/core/testing';

describe('HeaderComponent' , ()=> {
   let component : HeaderComponent; 
   let router : Router;
   beforeEach(()=>{
    TestBed.configureTestingModule({
        imports:[
          RouterTestingModule 
        ]})
       component = new HeaderComponent(router);
   })

   it("should create Header component", () => {
    expect(component).toBeTruthy();
  });

   it('should render details in H2 tag',()=> {
    const fixture = TestBed.createComponent(HeaderComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h2').textContent).toContain('HOME');
    
    });

    it("should redirect the user to app page" , ()=> {
      let router = TestBed.get(Router);
      let spy = spyOn(router,'navigateByUrl');
     // const navargs = spy.calls.first.arguments[0];
      component.onLogout();
      expect(spy).toBe('app');
    })
});