export class Student{
  constructor(public email: string, 
      public name: string, 
      public gender: string, 
      public mobile: string, 
      public course: string,
      public dateofbirth : string,
      public address:string) {}
}