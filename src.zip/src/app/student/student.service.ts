import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { Student } from "./student.model";
import {Notice} from '../notice/notice.model';
import { environment } from "src/environments/environment.prod";

@Injectable({providedIn: 'root'})
export class StudentService{

    constructor(private http: HttpClient){}

    userDetail = new Subject<Student>();
    allUsers = new Subject<Student[]>();
    allnotices = new Subject<Notice[]>();
    uri:string = "https://localhost:44396/";
    addStudent(student: Student){
     return this.http.post('https://localhost:44359/addstudent', student);
    }

    addNotice(notice: Notice){
        return this.http.post('https://localhost:44359/addnotice', notice);
       }
    getStudentsByCourse(course:string){
      let students: Student[];
        this.http.get<Student[]>('https://localhost:44359/studentsbycourse/'+course).subscribe((responseData) => {
            students = responseData;
            this.allUsers.next(students);
        });
    }

    getNotices(){
        let notices: Notice[];
          this.http.get<Notice[]>('https://localhost:44359/allNotices').subscribe((responseData) => {
              notices = responseData;
              this.allnotices.next(notices);
          });
      }

      getAllStudents(){
        let students: Student[];
        this.http.get<Student[]>('https://localhost:44359/allStudents').subscribe((responseData) => {
            students = responseData;
            this.allUsers.next(students);
        });
      }  
    
    getStudentByEmail(email : string){
        let student : Student;
        this.http.get<Student>('https://localhost:44359/studentbyid/'+ email).subscribe((responseData) => {
            student=responseData;    
            this.userDetail.next(student);
        });
    }

    updateStudent(email: string , user: Student){
        let student : Student;
        console.log("sri"+email);
       return this.http.put<Student>('https://localhost:44359/update',
        {
            email : user.email,
            name: user.name,
            mobile: user.mobile,
            gender : user.gender,
            address : user.address,            
            dateofbirth : user.dateofbirth,
            course :user.course           
        }
        );
    }

    deleteStudent(email : string){
        return this.http.delete('https://localhost:44359/delete/'+email).subscribe((responseData)=>{

        });
    }
   

    

}