import { TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms'; 
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import {UpdateStudentComponent} from './updatestudent.component';
import{StudentService} from '../../student/student.service';

describe('UpdateStudentComponent' , ()=> {
    let component : UpdateStudentComponent; 
    let router : Router;
    let service : StudentService;
    let route : ActivatedRoute;
    beforeEach(()=>{
     TestBed.configureTestingModule({
         imports:[
           RouterTestingModule 
         ]})
        component = new UpdateStudentComponent(route,router,service);
    })
 
    it("should create UpdateStudent component", () => {
        expect(component).toBeTruthy();
      });
 });