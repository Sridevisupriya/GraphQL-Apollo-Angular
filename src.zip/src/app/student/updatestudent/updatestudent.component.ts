import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import {StudentService} from '../../student/student.service';
import { Student } from 'src/app/student/student.model';
import { Subscription } from 'rxjs';
import { Apollo } from 'apollo-angular';
import {getstudentsbyemail} from '../../graphql/graphql.queries';
import {updatestudent} from'../../graphql/graphql.mutations';

@Component({
  selector: 'app-updatestudent',
  templateUrl: './updatestudent.component.html',
  styleUrls: ['./updatestudent.component.css']
})
export class UpdateStudentComponent implements OnInit {
  currentSelected : string = 'UpdateStudent';
  user: Student;
  isAccountUpdateSuccessfull=false;
  UserSubscription : Subscription;
  name:string;
  gender:string;
  mobile:string;
  address:string;
  dob:Date;
  constructor(private route: ActivatedRoute,private router: Router , private studentService:StudentService,private apollo:Apollo){
   
  }

  ngOnInit(): void { 

    this.route.params.subscribe((param) => {
      console.log(param['email']);
      this.apollo.watchQuery({
        query : getstudentsbyemail,
        variables : {email : param['email']}
      }) 
      .valueChanges.subscribe((result :any )=>{
        console.log(result)
        this.user=result?.data?.student
      });  
    });
    console.log(this.user);
    
  }
  onSubmit(form : NgForm){
    if(!form.valid){
      return;
    }
    const userDetail = new Student(
      this.user.email,
      form.value.name,
      form.value.gender,
      form.value.mobile,
      this.user.course,
      form.value.dob,
      form.value.address
      );
     
      this.apollo.mutate({
        mutation : updatestudent,
        variables : {email :this.user.email , student : userDetail }
      }).subscribe((res) =>{
        if(res){
          this.isAccountUpdateSuccessfull = true;  
          this.router.navigateByUrl('app/home/departments/departmentlists/'+ this.user.course);
      }});       
  }
}