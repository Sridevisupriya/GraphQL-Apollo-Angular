import { TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms'; 
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import {NoticeComponent} from './notice.component';
import{StudentService} from '../student/student.service';

describe('NoticeComponent' , ()=> {
    let component : NoticeComponent; 
    let router : Router;
    let service : StudentService;
    beforeEach(()=>{
     TestBed.configureTestingModule({
         imports:[
           RouterTestingModule 
         ]})
        component = new NoticeComponent(service , router);
    })
 
    it("should create Notice component", () => {
        expect(component).toBeTruthy();
      });
 });