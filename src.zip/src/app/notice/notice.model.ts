export class Notice{
    constructor(public noticeData: string, 
        public date: Date) {}
  }