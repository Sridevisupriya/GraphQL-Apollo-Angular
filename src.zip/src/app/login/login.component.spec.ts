import { TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms'; 
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import {LoginComponent} from './login.component';
describe('LoginComponent' , ()=> {
    let component : LoginComponent; 
    let router : Router;
    beforeEach(()=>{
     TestBed.configureTestingModule({
         imports:[
           RouterTestingModule 
         ]})
        component = new LoginComponent(router);
    })
 
    it("should create Login component", () => {
        expect(component).toBeTruthy();
      });

    it("should redirect the user to home page" , ()=> {
      let router = TestBed.get(Router);
      let spy = spyOn(router,'navigateByUrl');
      component.onSubmit;
    })
 });