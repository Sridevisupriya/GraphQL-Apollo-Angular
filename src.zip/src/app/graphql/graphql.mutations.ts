import {gql} from 'apollo-angular';

const addnotice = gql`
    mutation AddNotice($notice:NoticeInputType)
    {
        addNotice(notice:$notice)
        {
            id
            noticeData
            date
        }
    }
`;

const addstudent = gql`
    mutation AddStudent($student:StudentInputType){
        createStudent(student:$student)
        {
            name
            course
            email
            gender
            mobile
            address
            dateofbirth
        }
    }
`;


const updatestudent = gql`
  mutation updateStudent($email:String ,  $student:StudentInputType){
    updateStudent(email:$email , student:$student)
    {
        name
        course
        email
        gender
        mobile
        yearOfJoining
        address
        dateofbirth
    }
}`;

const deletestudent = gql`
    mutation deleteStudent($email:String){
        deleteStudent(email : $email)  
}`;

export {addnotice,addstudent,updatestudent,deletestudent};