import {gql} from 'apollo-angular';

const getallnotices = gql `
    query GetAllNotices{
        notices{
         id
         noticeData
         date
        }
    }`
    ;

const getstudentsbycourse = gql`
    query getStudentByCourse($course:String){  
    studentsbyCourse(course :$course){
        studentID
        name
        course
        email
        gender
        mobile
        dateofbirth
        yearOfJoining
        address
    }
}`
;

const getallstudents = gql `
    query GetAllStudents{  
        students{
        studentID
        name
        course
        email
        gender
        mobile
        yearOfJoining
        address
        dateofbirth
        }
  }`
  ;

  const getstudentsbyemail = gql`
  query getStudentByEmail($email:String){  
    student(email :$email){
        name
        course
        email
        gender
        mobile
        dateofbirth
        yearOfJoining
        address
  }
}`
;

export {getallnotices , getallstudents , getstudentsbycourse , getstudentsbyemail};

