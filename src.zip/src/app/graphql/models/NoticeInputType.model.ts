export class NoticeInputType{
    public noticeData: string
    public date: Date
  }