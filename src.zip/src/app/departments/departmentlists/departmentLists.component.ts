import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import {StudentService} from '../../student/student.service';
import { Student } from 'src/app/student/student.model';
import { Subscription } from 'rxjs';
import {getstudentsbycourse} from '../../graphql/graphql.queries';
import { Apollo } from 'apollo-angular';
import {deletestudent} from '../../graphql/graphql.mutations';

@Component({
  selector: 'app-branchlist',
  templateUrl: './departmentlists.component.html',
  styleUrls: ['./departmentlists.component.css']
})
export class DepartmentListComponent implements OnInit {
  currentSelected : string = 'DepartmentsList';
  users: Student[];
  allUserSubscription : Subscription;
  courseparam : string
  constructor(private route: ActivatedRoute,private router: Router , private studentService:StudentService, private apollo:Apollo){}

  ngOnInit(): void { 

   // this.studentService.getStudentsByCourse();
   this.route.params.subscribe((param) => {
    this.apollo.watchQuery({
      query : getstudentsbycourse,
      variables : {course : param['course']}
    }) 
    .valueChanges.subscribe((result :any )=>{
      this.users=result?.data?.studentsbyCourse
    });  
  });

    this.allUserSubscription = this.studentService.allUsers.subscribe((users) => {
      this.users = users;
      console.log(users);
    });  
  }
  onProceed(email : string){
    console.log(email);
    this.router.navigateByUrl('app/home/student/updatestudent/'+email);
  }

  onDelete(email : string){
    if(confirm("Are you sure?? \nYou want to delete "+ email)){      
      this.apollo.mutate({
        mutation: deletestudent,
        variables:{email:email}
      }).subscribe(console.log);        
    }
    this.router.navigateByUrl('app/home/departments');
    
  }

}