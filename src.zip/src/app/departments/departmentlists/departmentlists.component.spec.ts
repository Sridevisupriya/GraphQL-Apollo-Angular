import {DepartmentListComponent} from './departmentLists.component';
import{StudentService} from '../../student/student.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';

describe('DepartmentListComponent' , ()=> {
    let component : DepartmentListComponent;
    let service : StudentService;
    let route :  ActivatedRoute;
    let router :Router;
    beforeEach(()=>{
        service = new StudentService(null);
        component = new DepartmentListComponent(route,router ,service);
    })

    it("should create DepartmentList component", () => {
        expect(component).toBeTruthy();
      });

    it('should call the delete service to delete the student details from database',()=> {
        spyOn(window ,'confirm').and.returnValue(true);
        let spy = spyOn(service , 'deleteStudent').and.returnValue(Observable.length);

        component.onDelete('abc@gmail.com');
        expect(spy).toHaveBeenCalledWith('abc@gmail.com');
    })
});
