import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import{StudentService} from '../student/student.service';
import {Notice} from '../notice/notice.model';
import { Subscription } from 'rxjs';
import { Student } from '../student/student.model';
import { Apollo } from 'apollo-angular';
import {getallnotices , getallstudents} from '../graphql/graphql.queries';

@Component({
  selector: 'app-branch',
  templateUrl: './departments.component.html',
  styleUrls: ['./departments.component.css']
})
export class DepartmentsComponent implements OnInit {
  currentSelected : string = 'Departments';
  cse : string = "cse";
  ece : string = "ece";
  mech : string = "mech";
  eee : string = "eee";
  Notices : Notice[];
  Students : Student[];
  allUserSubscription : Subscription;
  constructor(private router: Router, private studentService:StudentService,private apollo:Apollo){
    this.Notices=[],
    this.Students=[],
    this.allUserSubscription = new Subscription()
  }

  ngOnInit(): void {   
    this.apollo
      .watchQuery({
        query : getallnotices,
      })
      .valueChanges.subscribe((result :any )=>{
        this.Notices=result?.data?.notices
      });

      this.apollo
      .watchQuery({
        query : getallstudents,
      })
      .valueChanges.subscribe((result :any )=>{
        this.Students=result?.data?.students
      });     
     
  }
  calculateDiff(dateSent:any){
    let currentDate = new Date();
    dateSent = new Date(dateSent);
    return Math.floor((Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()) - Date.UTC(dateSent.getFullYear(), dateSent.getMonth(), dateSent.getDate()) ) /(1000 * 60 * 60 * 24));
}
  onTouch(course:string){
    this.router.navigateByUrl('app/home/departments/departmentlists/'+ course);  
  }

  getCount()
  {
    return this.Students.length;
    
  }
  ngOnDestroy(): void {
   
}

}