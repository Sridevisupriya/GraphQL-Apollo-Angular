import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Apollo } from 'apollo-angular';
import {Student} from '../student/student.model';
import {StudentService} from '../student/student.service';
import {addstudent} from '../graphql/graphql.mutations';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-admission',
  templateUrl: './admission.component.html',
  styleUrls: ['./admission.component.css']
})
export class AdmissionComponent implements OnInit {
  currentSelected : string = 'Header';
  public datepipe: DatePipe;
  errorMessage = '';
  phone='';
  successfullMessage='';
  options = [
    {key: 1, value:"CSE"},
    {key: 2, value:"ECE"},
    {key: 3, value:"MECH"},
    {key: 4, value:"EEE"}
  ]
  constructor(private studentService: StudentService , private router: Router, private apollo :Apollo) { }

  ngOnInit(): void {
  }

  onAddStudent(form: NgForm){

    if(!form.valid){
      this.errorMessage = "Please fill all the fields!";
      return;
    }
    else{
      this.phone =form.value.mobile;
      if(this.phone.length!=10)
      {
        this.errorMessage = "Mobile number should have 10 digits";
        return;
      }
      const student = new Student(
        form.value.email, 
        form.value.name, 
        form.value.gender, 
        form.value.mobile, 
        form.value.course, 
        form.value.dateOfBirth+"",
        form.value.address)
  
        
        console.log(student);
        this.apollo
          .mutate({
            mutation : addstudent,
            variables:{student : student}
          }).subscribe(console.log);
        
        this.router.navigateByUrl('app/home/departments');
    }
  }
}